$(window).scroll(function(e) {
    var distanceScrolled = $(this).scrollTop();
    $('.main-hero').css('-webkit-filter', 'blur(' + distanceScrolled / 60 + 'px)');
});